from django.db import models

from django.core.validators import EmailValidator


#from django.contrib.messages import constants as messages


class contactForm(models.Model):
   
    name = models.CharField(max_length=100)
    email = models.CharField(max_length=100 ,validators=[EmailValidator()])
    desc = models.TextField()
    #date = models.DateField()
     

def __str__(self):
    return self.name
    
