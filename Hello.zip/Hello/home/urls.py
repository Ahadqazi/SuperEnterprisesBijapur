from django.contrib import admin
from django.urls import path
from home import views
admin.site.site_header='Sarfaraz Inamdar'

urlpatterns = [
      path("",views.index,name='home'),
      path("about" , views.about,name='about'),
      path("ContactForm",views.ContactForm, name='ContactForm'),
      path("service",views.service, name='service')  
      
 ] 

