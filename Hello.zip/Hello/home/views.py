#from tokenize import Name
from django.shortcuts import render
from  home.models import contactForm
#from django.contrib.messages import constants as messages


#from home.views import ContactForm



def service(request): 
    return render(request,'service.html')
    #return HttpResponse("this is service",request)def service(request): 
   
    #return Htt






# Create your views here
def index(request):
    

    # messages.success(request,"this is a text message" )
     return render(request,'index.html')




def about(request): 
    return render(request,'about.html')
    #return HttpResponse("this is aboutpage",request)

def service(request): 
    return render(request,'service.html')
    #return HttpResponse("this is service",request)


def ContactForm(request):
 

    if request.method == 'POST':
    
        name = request.POST.get('name','')
        email = request.POST.get('email','')
        desc = request.POST.get('desc','')
        print(name, email,  desc)
        ContactForm = contactForm(name=name, email=email, desc=desc)
        ContactForm.save()
       # messages.success(request,'your message has been sent')

        
         
    return render(request,'ContactForm.html')



        #ContactForm = contactForm (name=name, email=email, desc=desc)
        #ContactForm.save()
      
   
    #return HttpResponse("this is service",request)


#def ContactForm(request):
    #return render(request,'home/Temp/ContactFORM.html')

        

